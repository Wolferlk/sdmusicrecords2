export interface Product {
  _id: string;
  name: string;
  description: string;
  price: number;
  category: 'mens' | 'womens' | 'caps' | 'bags' | 'shoes';
  sizes: string[];
  colors: string[];
  images: string[];
  quantity: number;
  status: 'available' | 'sold_out';
  createdAt: Date;
  updatedAt: Date;
}

export interface User {
  _id: string;
  name: string;
  email: string;
  role: 'user' | 'manager';
  createdAt: Date;
}

export interface Order {
  _id: string;
  user: {
    name: string;
    phone1: string;
    phone2: string;
    address: string;
  };
  products: {
    product: Product;
    quantity: number;
    size: string;
    color: string;
  }[];
  totalAmount: number;
  status: 'pending' | 'completed' | 'declined';
  createdAt: Date;
}

export interface CartItem {
  product: Product;
  quantity: number;
  size: string;
  color: string;
}