import { Link } from 'react-router-dom';
import { Product } from '../types';
import { useCart } from '../context/CartContext';
import toast from 'react-hot-toast';

interface ProductCardProps {
  product: Product;
}

export default function ProductCard({ product }: ProductCardProps) {
  const { dispatch } = useCart();

  const addToCart = () => {
    dispatch({
      type: 'ADD_TO_CART',
      payload: {
        product,
        quantity: 1,
        size: product.sizes[0],
        color: product.colors[0]
      }
    });
    toast.success('Added to cart');
  };

  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden">
      <Link to={`/product/${product._id}`}>
        <img
          src={product.images[0]}
          alt={product.name}
          className="w-full h-64 object-cover hover:opacity-90 transition-opacity"
        />
      </Link>
      <div className="p-4">
        <Link to={`/product/${product._id}`}>
          <h3 className="text-lg font-semibold mb-2">{product.name}</h3>
        </Link>
        <div className="flex justify-between items-center mb-2">
          <span className="text-xl font-bold">${product.price}</span>
          <span className="text-sm text-gray-600">
            {product.status === 'available' ? 'In Stock' : 'Sold Out'}
          </span>
        </div>
        <div className="flex flex-wrap gap-2 mb-3">
          {product.sizes.map(size => (
            <span key={size} className="text-xs border px-2 py-1 rounded">
              {size}
            </span>
          ))}
        </div>
        <div className="flex gap-2 mb-4">
          {product.colors.map(color => (
            <div
              key={color}
              className="w-4 h-4 rounded-full border"
              style={{ backgroundColor: color }}
            />
          ))}
        </div>
        <div className="flex gap-2">
          <button
            onClick={addToCart}
            disabled={product.status !== 'available'}
            className={`flex-1 py-2 px-4 rounded ${
              product.status === 'available'
                ? 'bg-black text-white hover:bg-gray-800'
                : 'bg-gray-300 cursor-not-allowed'
            }`}
          >
            Add to Cart
          </button>
          <Link
            to={`/product/${product._id}`}
            className="py-2 px-4 border border-black rounded hover:bg-gray-100"
          >
            View
          </Link>
        </div>
      </div>
    </div>
  );
}