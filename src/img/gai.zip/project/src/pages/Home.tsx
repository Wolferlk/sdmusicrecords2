import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';

export default function Home() {
  return (
    <div className="space-y-20">
      {/* Hero Section */}
      <section className="relative h-screen">
        <img
          src="https://images.unsplash.com/photo-1441984904996-e0b6ba687e04"
          alt="Hero"
          className="absolute inset-0 w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-black bg-opacity-50" />
        <div className="absolute inset-0 flex items-center justify-center text-white text-center">
          <div className="space-y-6">
            <h1 className="text-6xl font-bold">CANNIBLE.CO</h1>
            <p className="text-xl">Redefining Street Fashion</p>
            <Link
              to="/store"
              className="inline-block bg-white text-black px-8 py-3 rounded-full hover:bg-gray-100"
            >
              Shop Now
            </Link>
          </div>
        </div>
      </section>

      {/* Featured Categories */}
      <section className="container mx-auto px-4">
        <h2 className="text-3xl font-bold mb-8">Shop by Category</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {[
            {
              title: "Men's Collection",
              image: "https://images.unsplash.com/photo-1516826957135-700dedea698c"
            },
            {
              title: "Women's Collection",
              image: "https://images.unsplash.com/photo-1483985988355-763728e1935b"
            },
            {
              title: "Accessories",
              image: "https://images.unsplash.com/photo-1523779917675-b6ed3a42a561"
            }
          ].map((category) => (
            <Link
              key={category.title}
              to="/store"
              className="relative group overflow-hidden"
            >
              <img
                src={category.image}
                alt={category.title}
                className="w-full h-96 object-cover transition-transform group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-black bg-opacity-40 flex items-center justify-center">
                <h3 className="text-white text-2xl font-bold">{category.title}</h3>
              </div>
            </Link>
          ))}
        </div>
      </section>

      {/* Featured Products */}
      <section className="bg-gray-100 py-20">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-center mb-8">
            <h2 className="text-3xl font-bold">New Arrivals</h2>
            <Link
              to="/store"
              className="flex items-center text-lg hover:underline"
            >
              View All <ArrowRight className="ml-2 w-5 h-5" />
            </Link>
          </div>
          {/* Product grid will be populated dynamically */}
        </div>
      </section>

      {/* Newsletter */}
      <section className="container mx-auto px-4 text-center py-20">
        <h2 className="text-3xl font-bold mb-4">Join Our Newsletter</h2>
        <p className="text-gray-600 mb-8">
          Subscribe to get special offers, free giveaways, and updates.
        </p>
        <form className="max-w-md mx-auto flex gap-4">
          <input
            type="email"
            placeholder="Enter your email"
            className="flex-1 px-4 py-2 border border-gray-300 rounded focus:outline-none focus:border-black"
          />
          <button
            type="submit"
            className="bg-black text-white px-8 py-2 rounded hover:bg-gray-800"
          >
            Subscribe
          </button>
        </form>
      </section>
    </div>
  );
}