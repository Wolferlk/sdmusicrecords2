export default function About() {
  return (
    <div className="max-w-4xl mx-auto">
      <h1 className="text-4xl font-bold mb-8">About CANNIBLE.CO</h1>
      
      <div className="space-y-8">
        <section>
          <h2 className="text-2xl font-semibold mb-4">Our Story</h2>
          <p className="text-gray-600 leading-relaxed">
            Founded in 2024, CANNIBLE.CO emerged from a passion for street fashion and urban culture. 
            We believe that clothing is more than just fabric – it's a form of self-expression, 
            a statement of individuality, and a reflection of contemporary culture.
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-semibold mb-4">Our Mission</h2>
          <p className="text-gray-600 leading-relaxed">
            At CANNIBLE.CO, we're committed to delivering high-quality streetwear that combines 
            bold design with comfortable wearability. We strive to create clothing that empowers 
            individuals to express their unique style while maintaining the highest standards of 
            quality and sustainability.
          </p>
        </section>

        <section className="grid grid-cols-1 md:grid-cols-3 gap-8 py-8">
          <div className="text-center">
            <h3 className="font-semibold mb-2">Quality First</h3>
            <p className="text-gray-600">Premium materials and expert craftsmanship in every piece</p>
          </div>
          <div className="text-center">
            <h3 className="font-semibold mb-2">Sustainable Fashion</h3>
            <p className="text-gray-600">Eco-friendly practices and responsible production</p>
          </div>
          <div className="text-center">
            <h3 className="font-semibold mb-2">Community Driven</h3>
            <p className="text-gray-600">Supporting and inspired by urban culture</p>
          </div>
        </section>

        <section>
          <h2 className="text-2xl font-semibold mb-4">Join Our Journey</h2>
          <p className="text-gray-600 leading-relaxed">
            We invite you to be part of our growing community. Whether you're a fashion enthusiast, 
            streetwear collector, or someone who appreciates quality clothing, CANNIBLE.CO is here 
            to serve your style needs.
          </p>
        </section>
      </div>
    </div>
  );
}